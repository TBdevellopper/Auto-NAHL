function[net]=Auto_NAHL(Tr_Inputs,Tr_Tragets,Ts_Inputs,Ts_Tragets,Options)
% Auto_NAHL: A Neural network with augmented Hidden layer. 
% The list of hyperparameters should contain {Number of Hidden Neurons , ActivationFunction type, and the waintening parameter gamma}
% Tr_Inputs : training inputs.
% Tr_Tragtes: training labels.
% Ts_Inputs : testing inputs.
% Ts_Tragtes: testing labels.
% Options.LB: Lower band constraints for the hyperparameters
% Options.UB: Upper band constraints for the hyperparameters
% Options.n : number of population.
% Options.NAHL_Type: NAHL_Type is 0 for regression and 1 for classification
% net: this variable contains the important Characteristics  of trained
% algorithm
% Options.maxite= Maximum allowed number of iterations
% Options.T; desired telerance error 
% Options.StepTolerance; step between calculated errors
%  


% Initialize the PSO parameters
LB=Options.LB; % 
UB=Options.UB; %
maxite=Options.maxite; % set maximum number of iteration 
n=Options.n;   % number of population
T=Options.T; %desired telerance error 
m=length(LB);  % number of variables in each individual.
NAHL_Type=Options.NAHL_Type;
StepTolerance=Options.StepTolerance; % step between calculated errors
% Solving Optimization problem based on random search mechanism

[net]=PSO_N(m,n,LB,UB,maxite,T,NAHL_Type,StepTolerance,Tr_Inputs,Tr_Tragets,Ts_Inputs,Ts_Tragets);%

end
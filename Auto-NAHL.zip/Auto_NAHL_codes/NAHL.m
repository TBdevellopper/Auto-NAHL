function [net] = NAHL(xtr,xts,ytr,yts, NAHL_Type,gamma,NumberofHiddenNeurons, ActivationFunction)

% NAHL: A Neural network with an Augmanted Hidden Layer
% Input:
% xtr    -traininh inputs
% ytr    -training tagets
% xts    -testing inputs
% yts    -testing targets
% gamma  -discount parameters
% NAHL_Type - 0 for regression and 1 for classification
% NumberofHiddenNeurons - Number of hidden neurons assigned to the ELM
% ActivationFunction    - Type of activation function:
%                           'sig' for Sigmoidal function
%                           'sin' for Sine function
%                           'hardlim' for Hardlim function
%                           'tribas' for Triangular basis function
%                           'radbas' for Radial basis function (for additive type of SLFNs instead of RBF type of SLFNs)
%
% Output: 
% net    -fully trained network
%
% MULTI-CLASSE CLASSIFICATION: NUMBER OF OUTPUT NEURONS WILL BE AUTOMATICALLY SET EQUAL TO NUMBER OF CLASSES
% FOR EXAMPLE, if there are 7 classes in all, there will have 7 output
% neurons; neuron 5 has the highest output means input belongs to 5-th class
%
%


%%%%%%%%%%% Macro definition
REGRESSION=0;
CLASSIFIER=1;
%%%%%%%%%%% Load training dataset
T=ytr';
P=xtr';
%%%%%%%%%%% Load testing dataset
TV.T=yts';
TV.P=xts';
NumberofTrainingData=size(P,2);
NumberofTestingData=size(TV.P,2);
NumberofInputNeurons=size(P,1);

if NAHL_Type~=REGRESSION
    %%%%%%%%%%%% Preprocessing the data of classification
    sorted_target=sort(cat(2,T,TV.T),2);
    label=zeros(1,1);                               %   Find and save in 'label' class label from training and testing data sets
    label(1,1)=sorted_target(1,1);
    j=1;
    for i = 2:(NumberofTrainingData+NumberofTestingData)
        if sorted_target(1,i) ~= label(1,j)
            j=j+1;
            label(1,j) = sorted_target(1,i);
        end
    end
    number_class=j;
    NumberofOutputNeurons=number_class;
       
    %%%%%%%%%% Processing the targets of training
    temp_T=zeros(NumberofOutputNeurons, NumberofTrainingData);
    for i = 1:NumberofTrainingData
        for j = 1:number_class
            if label(1,j) == T(1,i)
                break; 
            end
        end
        temp_T(j,i)=1;
    end
    T=temp_T*2-1;

    %%%%%%%%%% Processing the targets of testing
    temp_TV_T=zeros(NumberofOutputNeurons, NumberofTestingData);
    for i = 1:NumberofTestingData
        for j = 1:number_class
            if label(1,j) == TV.T(1,i)
                break; 
            end
        end
        temp_TV_T(j,i)=1;
    end
    TV.T=temp_TV_T*2-1;

end                                                 %   end if of NAHL_Type

%%%%%%%%%%% Calculate weights & biases
start_time_train=cputime;

%%%%%%%%%%% Random generate input weights InputWeight (w_i) and biases BiasofHiddenNeurons (b_i) of hidden neurons
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~NAHL
rng('default')
tempH=0;
N_Slices=length(gamma);
for i= 1:N_Slices

InputWeight{i}=rand(NumberofHiddenNeurons,NumberofInputNeurons)*2-1;
BiasofHiddenNeurons{i}=rand(NumberofHiddenNeurons,1);
ind=ones(1,NumberofTrainingData);
BiasMatrix{i}=BiasofHiddenNeurons{i}(:,ind);              %   Extend the bias matrix BiasofHiddenNeurons to match the demention of H
tempH=(tempH+BiasMatrix{i})+(gamma(i)*(InputWeight{i}*P));

end
s=load('s.mat');
s=s.s;
rng(s)
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~end NAHL
clear P;                                            %   Release input of training data 


%%%%%%%%%%% Calculate hidden neuron output matrix H

switch lower(ActivationFunction)
    case {1}
        %%%%%%%% Sigmoid 
        H = 1 ./ (1 + exp(-tempH));
    case {2}
        %%%%%%%% Sine
        H = sin(tempH);    
    case {3}
        %%%%%%%% Hard Limit
        H = double(hardlim(tempH));
    case {4}
        %%%%%%%% Triangular basis function
        H = tribas(tempH);
    case {5}
        %%%%%%%% Radial basis function
        H = radbas(tempH);
        %%%%%%%% More activation functions can be added here  
    case {6}
        %%%%%%%% RelU
        H = max(tempH,0);
end
clear tempH;                                        %   Release the temparary array for calculation of hidden neuron output matrix H

%%%%%%%%%%% Calculate output weights OutputWeight (beta_i)
OutputWeight=pinv(H') * T';                        % implementation without regularization factor //refer to 2006 Neurocomputing paper

end_time_train=cputime;
TrainingTime=end_time_train-start_time_train;        %   Calculate CPU time (seconds) spent for training ELM

%%%%%%%%%%% Calculate the training accuracy
Y=(H' * OutputWeight)';                             %   Y: the actual output of the training data
clear H;

%%%%%%%%%%% Calculate the output of testing input
start_time_test=cputime;
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~NAHL
tempH_test=0;
for i=1:N_Slices
ind=ones(1,NumberofTestingData);
BiasMatrix{i}=BiasofHiddenNeurons{i}(:,ind);   
tempH_test=(tempH_test+BiasMatrix{i})+(gamma(i)*(InputWeight{i}*TV.P));
         
end
clear TV.P;             %   Release input of testing data 
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~
%~~~~~~~~~~end NAHL
switch lower(ActivationFunction)
    case {1}
        %%%%%%%% Sigmoid 
        H_test = 1 ./ (1 + exp(-tempH_test));
    case {2}
        %%%%%%%% Sine
        H_test = sin(tempH_test);        
    case {3}
        %%%%%%%% Hard Limit
        H_test = hardlim(tempH_test);        
    case {4}
        %%%%%%%% Triangular basis function
        H_test = tribas(tempH_test);        
    case {5}
        %%%%%%%% Radial basis function
        H_test = radbas(tempH_test);        
        %%%%%%%% More activation functions can be added here  
    case {6}
        %%%%%%%% RelU
        H_test = max(tempH_test,0);
end
TY=(H_test' * OutputWeight)';                        %   TY: the actual output of the testing data
end_time_test=cputime;
TestingTime=end_time_test-start_time_test;           %   Calculate CPU time (seconds) spent by ELM predicting the whole testing data
%%%
if NAHL_Type == REGRESSION
    TrainingAccuracy=sqrt(mse(T - Y)) ;              %   Calculate training accuracy (RMSE) for regression case
    TestingAccuracy=sqrt(mse(TV.T - TY));            %   Calculate testing accuracy (RMSE) for regression case
end
if NAHL_Type == CLASSIFIER
[TrainingAccuracy,TestingAccuracy]=Cl_acc(T,Y,TV.T,TY);
end
loss=sqrt(mse(TV.T,TY));


%% save results of the network
net.loss=loss;
net.gamma=gamma;
net.W=InputWeight;
net.B=OutputWeight;
net.TrainingTime=TrainingTime;
net.TestingTime=TestingTime;
net.TrainingAccuracy=TrainingAccuracy;
net.TestingAccuracy=TestingAccuracy;
net.yts_hat=TY;
net.yts=TV.T;
end
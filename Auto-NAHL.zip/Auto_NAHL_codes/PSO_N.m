function [net]=PSO_N(m,n,LB,UB,maxite,T,NAHL_Type,StepTolerance,Tr_Inputs,Tr_Tragets,Ts_Inputs,Ts_Tragets)%
% ----inputs
% LB: lower band for each variable
% UB: Upper band for each variable
% m : number of variables
% n : number of populatipn
% NAHL_Type is 0 for regression and 1 for classification
% initialize parameters
% ----outputs
% net: trained Algorithm
wmax=0.9;    % inertial weight
wmin=0.4;    % inertial weight
c1=2;        % acceleration factor
c2=2;        % acceleration factor

% pso initialization
 for i=1:n
 for j=1:m
 x0(i,j)=(LB(j)+rand()*(UB(j)-LB(j)));
 end
 end
 
 x=x0;     % initial population
 initial_pop=x0;    

 v=0.1*x0; % initial velocity
 for i=1:n
 f0(i,1)=ofun_N(x0(i,:),NAHL_Type,Tr_Inputs,Tr_Tragets,Ts_Inputs,Ts_Tragets);
 end
 [fmin0,index0]=min(f0);
 pbest=x0; % initial pbest
 gbest=x0(index0,:); % initial gbest
 % pso initialization------------------------------------------------end

 % pso algorithm---------------------------------------------------start
 ite=0;
 tolerance=1;
  while ite<=maxite 
 tolerance;
 ite=ite+1;

 w=wmax-(wmax-wmin)*ite/maxite; % update inertial weight
 % pso velocity updates
 for i=1:n
 for j=1:m
 v(i,j)=w*v(i,j)+c1*rand()*(pbest(i,j)-x(i,j))...
 +c2*rand()*(gbest(1,j)-x(i,j));
 end
 end
 % pso position update
 for i=1:n
 for j=1:m
 x(i,j)=round(x(i,j)+v(i,j));
 end
 end
 
 % handling boundary violations
 for i=1:n
 for j=1:m
 if x(i,j)<LB(j)
 x(i,j)=LB(j);
 elseif x(i,j)>UB(j)
 x(i,j)=UB(j);
 end
 end
 end
 % evaluating fitness
 for i=1:n
 [f(i,1),net]=ofun_N(x(i,:),NAHL_Type,Tr_Inputs,Tr_Tragets,Ts_Inputs,Ts_Tragets);
 end
 % updating pbest and fitness (best population)
 for i=1:n
 if f(i,1)<f0(i,1)
 pbest(i,:)=x(i,:);
 f0(i,1)=f(i,1);
 end

 end
 [fmin,index]=min(f0); % finding out the best particle
 fit(ite)=fmin;        % storing best fitness
 % updating gbest and best fitness (gbest= best particle))
 if fmin<fmin0
 gbest=pbest(index,:);
 fmin0=fmin;
 end
 % displaying iterative results
 if ite==1
 disp(sprintf('Iteration Best particle Loss'));
 end
 disp(sprintf('%8g %8g %8.4f',ite,index,fit(ite)));
 % calculating tolerance rate
 if ite>StepTolerance
%  The norm of (previous & current error)
 tolerance=sqrt(mse(fit(ite)-fit(ite-StepTolerance)));
 end
 if tolerance <= T
     break
 end

 end
 disp(sprintf('Tolerance'));
 disp(sprintf('%8.4f\n',tolerance));
 final_pop=x;
 % pso algorithm-----------------------------------------------------end
 bvariables=gbest;  % best variables
 fit_behavior=fit;  % fitness function behavior during random search
 nb_iterations=ite; % namver of iterations
 % evaluate fitness function
[~,net]=ofun_N(bvariables,NAHL_Type,Tr_Inputs,Tr_Tragets,Ts_Inputs,Ts_Tragets);%
bvariables(1:2)=round(bvariables(1:2));
net.bvariables=bvariables;
net.nb_iterations=nb_iterations;
net.fit_behavior= fit_behavior;
net.final_pop=final_pop;
net.initial_pop=initial_pop;
end
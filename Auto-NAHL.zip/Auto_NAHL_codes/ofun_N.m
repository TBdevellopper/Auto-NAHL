function [fitness,net]=ofun_N(x,NAHL_Type,Tr_Inputs,Tr_Tragets,Ts_Inputs,Ts_Tragets)
% x: current population
% NAHL_Type is 0 for regression and 1 for classification
% objective function (minimization)
NumberofHiddenNeurons=round(x(1));
ActivationFunction=round(x(2));
gamma= x(3:end);
net = NAHL(Tr_Inputs,Ts_Inputs,Tr_Tragets,Ts_Tragets,NAHL_Type,gamma,NumberofHiddenNeurons, ActivationFunction);
% fitness function
fitness=net.loss; % fitness function

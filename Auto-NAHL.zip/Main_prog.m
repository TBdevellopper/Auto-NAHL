% Please read This paper carefully and cite it in your work as:
% Berghout, T.; Benbouzid, M.; Muyeen, S.M.; Bentrcia, T.; Mouss, L.-H. 
% Auto-NAHL: A Neural Network Approach for Condition-based Maintenance of Complex Industrial Systems.
% IEEE Access 2021, 10, 1�1, doi:10.1109/ACCESS.2021.3127084.

% Updates(23-12-2021):
% New activation function ReLU is Added
% Problem with tolerance desired value is fixed
% Some important illustration are added (figures)
% Fitness function is replaced with RMSE loss function 
% The code is able to adapt with both regression and classification
% New options has been added to select regression and classification
% New options about tolerance of error and stopping criteria are added


clear all 
clc
addpath('Auto_NAHL_codes')
%% Load your data
x=load('wine_dataset');
Inputs=x.wineInputs';
Taregets=x.wineTargets';
%% Devide data (training and testing sets)
Q=size(Inputs,1);% Total number of samples
trainRatio=0.5;  % Training ratio
testRatio=1-trainRatio; % Testing ratio
[trainInd,~,testInd] = divideint(Q,trainRatio,0,testRatio);% Deviding index
%% Define Inputs and outputs
xtr= Inputs(trainInd,:);
xts= Inputs(testInd,:);
ytr= Taregets(trainInd,:);
yts= Taregets(testInd,:);
% 
clearvars -except xtr xts ytr yts
%% Traning and testing of Auto-NAHL

% Initial variables
% Concerning LB and UB the first two parameters are NumberofHiddenNeurons &
% ActivationFunction resepectively. other parameters are the discount
% parameters bounds. The number of discount parameters is the same as
% number of temoporary hidden layers
% 
Options.LB=[2 1 0 0 0 ];  % Lower bounds
Options.UB=[600 6 1 1 1]; % Upper bounds
Options.maxite=100;       % set maximum number of iteration 
Options.T=10^-6;          % desired telerance error 
Options.n=50;             % number of population
Options.NAHL_Type=1;      % NAHL_Type is 0 for regression and 1 for classification
Options.StepTolerance=20; % step between calculated errors
%% Application (training and testing)
[net] = Auto_NAHL(xtr,ytr,xts,yts,Options)
%
clearvars -except net 
%% Plotting population updates and convergence characteristics
figure(1)
Activations_names={'Sigmoid', 'Sine', 'Hardlim', 'Tribas', 'RBF','ReLU'};
Neurons=round(net.initial_pop(:,1));
Activations=round(net.initial_pop(:,2));
subplot(1,3,1)
plot(Neurons,Activations,'*');
xlabel('Neurons')
ylabel('Activation function')
set(gca,'ytick',[1:6],'yticklabel',Activations_names)
title('Initial population')
ylim([-1 7])
subplot(1,3,2)
updated_Neurons=round(net.final_pop(:,1));
updated_Activations=round(net.final_pop(:,2));
plot(updated_Neurons,updated_Activations,'*');
xlabel('Neurons')
ylabel('Activation function')
set(gca,'ytick',[1:6],'yticklabel',Activations_names)
title('Updated population')
ylim([-1 7])
subplot(1,3,3)
index=1:net.nb_iterations;
plot(index,smooth(net.fit_behavior));
xlabel('Iteration')
ylabel('loss')
title('fitness function behaviour')
